import os
import sqlite3
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, send_from_directory
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

# ------------------------------------------------------------------
# App configuration
# ------------------------------------------------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "school_portal.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg"}
MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MB

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key-in-production"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ------------------------------------------------------------------
# Database helpers
# ------------------------------------------------------------------
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'student',
            student_id TEXT,
            course TEXT,
            year_level TEXT,
            contact_number TEXT,
            address TEXT,
            created_at TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            doc_type TEXT NOT NULL,
            filename TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            reason TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            date_applied TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    """)

    # Seed one default admin account if none exists yet
    admin = cur.execute("SELECT * FROM users WHERE role = 'admin'").fetchone()
    if admin is None:
        cur.execute("""
            INSERT INTO users (full_name, email, password_hash, role, created_at)
            VALUES (?, ?, ?, 'admin', ?)
        """, (
            "System Admin",
            "admin@school.edu",
            generate_password_hash("admin123"),
            datetime.now().isoformat()
        ))

    conn.commit()
    conn.close()


def allowed_file(filename):
    return "." in filename and \
        filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ------------------------------------------------------------------
# Access-control decorators
# ------------------------------------------------------------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session or session.get("role") != "student":
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session or session.get("role") != "admin":
            flash("Please log in as admin to continue.", "warning")
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return wrapper


# ------------------------------------------------------------------
# Public
# ------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


# ------------------------------------------------------------------
# Student: Register / Login / Logout
# ------------------------------------------------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not full_name or not email or not password:
            flash("Please fill in all required fields.", "danger")
            return redirect(url_for("register"))

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "danger")
            return redirect(url_for("register"))

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for("register"))

        conn = get_db()
        existing = conn.execute(
            "SELECT id FROM users WHERE email = ?", (email,)
        ).fetchone()

        if existing:
            flash("An account with that email already exists.", "danger")
            conn.close()
            return redirect(url_for("register"))

        conn.execute("""
            INSERT INTO users (full_name, email, password_hash, role, created_at)
            VALUES (?, ?, ?, 'student', ?)
        """, (full_name, email, generate_password_hash(password), datetime.now().isoformat()))
        conn.commit()
        conn.close()

        flash("Account created successfully. You can now log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email = ? AND role = 'student'", (email,)
        ).fetchone()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["role"] = "student"
            flash(f"Welcome back, {user['full_name']}!", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


# ------------------------------------------------------------------
# Student: Dashboard / Profile
# ------------------------------------------------------------------
@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    conn = get_db()
    user_id = session["user_id"]

    if request.method == "POST":
        student_id = request.form.get("student_id", "").strip()
        course = request.form.get("course", "").strip()
        year_level = request.form.get("year_level", "").strip()
        contact_number = request.form.get("contact_number", "").strip()
        address = request.form.get("address", "").strip()

        conn.execute("""
            UPDATE users
            SET student_id = ?, course = ?, year_level = ?,
                contact_number = ?, address = ?
            WHERE id = ?
        """, (student_id, course, year_level, contact_number, address, user_id))
        conn.commit()
        flash("Profile updated successfully.", "success")

    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    documents = conn.execute(
        "SELECT * FROM documents WHERE user_id = ?", (user_id,)
    ).fetchall()
    application = conn.execute(
        "SELECT * FROM applications WHERE user_id = ? ORDER BY id DESC LIMIT 1",
        (user_id,)
    ).fetchone()
    conn.close()

    doc_map = {doc["doc_type"]: doc for doc in documents}

    return render_template(
        "dashboard.html",
        user=user,
        doc_map=doc_map,
        application=application
    )


# ------------------------------------------------------------------
# Student: Upload documents (Valid ID / Credentials)
# ------------------------------------------------------------------
@app.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    user_id = session["user_id"]
    conn = get_db()

    if request.method == "POST":
        doc_type = request.form.get("doc_type")
        file = request.files.get("document")

        if doc_type not in ("valid_id", "credentials"):
            flash("Invalid document type.", "danger")
            conn.close()
            return redirect(url_for("upload"))

        if not file or file.filename == "":
            flash("Please choose a file to upload.", "danger")
            conn.close()
            return redirect(url_for("upload"))

        if not allowed_file(file.filename):
            flash("Only PDF, JPG and PNG files are allowed.", "danger")
            conn.close()
            return redirect(url_for("upload"))

        ext = file.filename.rsplit(".", 1)[1].lower()
        filename = secure_filename(f"user{user_id}_{doc_type}.{ext}")
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(filepath)

        existing = conn.execute(
            "SELECT * FROM documents WHERE user_id = ? AND doc_type = ?",
            (user_id, doc_type)
        ).fetchone()

        if existing:
            conn.execute("""
                UPDATE documents SET filename = ?, uploaded_at = ?
                WHERE id = ?
            """, (filename, datetime.now().isoformat(), existing["id"]))
        else:
            conn.execute("""
                INSERT INTO documents (user_id, doc_type, filename, uploaded_at)
                VALUES (?, ?, ?, ?)
            """, (user_id, doc_type, filename, datetime.now().isoformat()))

        conn.commit()
        conn.close()
        flash("Document uploaded successfully.", "success")
        return redirect(url_for("dashboard"))

    documents = conn.execute(
        "SELECT * FROM documents WHERE user_id = ?", (user_id,)
    ).fetchall()
    conn.close()
    doc_map = {doc["doc_type"]: doc for doc in documents}

    return render_template("upload.html", doc_map=doc_map)


# ------------------------------------------------------------------
# Student: Apply for scholarship
# ------------------------------------------------------------------
@app.route("/apply", methods=["GET", "POST"])
@login_required
def apply():
    user_id = session["user_id"]
    conn = get_db()

    documents = conn.execute(
        "SELECT * FROM documents WHERE user_id = ?", (user_id,)
    ).fetchall()
    doc_types = {doc["doc_type"] for doc in documents}

    existing_application = conn.execute("""
        SELECT * FROM applications
        WHERE user_id = ? AND status IN ('Pending', 'Approved')
        ORDER BY id DESC LIMIT 1
    """, (user_id,)).fetchone()

    if request.method == "POST":
        if "valid_id" not in doc_types or "credentials" not in doc_types:
            flash("Please upload your Valid ID and Credentials before applying.", "danger")
            conn.close()
            return redirect(url_for("upload"))

        if existing_application:
            flash("You already have an active application.", "warning")
            conn.close()
            return redirect(url_for("dashboard"))

        reason = request.form.get("reason", "").strip()
        if not reason:
            flash("Please provide a reason for your application.", "danger")
            conn.close()
            return redirect(url_for("apply"))

        conn.execute("""
            INSERT INTO applications (user_id, reason, status, date_applied)
            VALUES (?, ?, 'Pending', ?)
        """, (user_id, reason, datetime.now().isoformat()))
        conn.commit()
        conn.close()

        flash("Scholarship application submitted successfully.", "success")
        return redirect(url_for("dashboard"))

    conn.close()
    return render_template(
        "apply.html",
        doc_types=doc_types,
        existing_application=existing_application
    )


# ------------------------------------------------------------------
# Admin: Login / Logout
# ------------------------------------------------------------------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        admin = conn.execute(
            "SELECT * FROM users WHERE email = ? AND role = 'admin'", (email,)
        ).fetchone()
        conn.close()

        if admin and check_password_hash(admin["password_hash"], password):
            session["user_id"] = admin["id"]
            session["full_name"] = admin["full_name"]
            session["role"] = "admin"
            flash("Welcome back, Admin.", "success")
            return redirect(url_for("admin_dashboard"))

        flash("Invalid admin credentials.", "danger")
        return redirect(url_for("admin_login"))

    return render_template("admin_login.html")


@app.route("/admin/logout")
def admin_logout():
    session.clear()
    flash("Admin logged out.", "info")
    return redirect(url_for("index"))


# ------------------------------------------------------------------
# Admin: Dashboard (list students)
# ------------------------------------------------------------------
@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    conn = get_db()
    students = conn.execute(
        "SELECT * FROM users WHERE role = 'student' ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return render_template("admin_dashboard.html", students=students)


@app.route("/admin/student/<int:student_id>")
@admin_required
def admin_view_student(student_id):
    conn = get_db()
    student = conn.execute(
        "SELECT * FROM users WHERE id = ? AND role = 'student'", (student_id,)
    ).fetchone()

    if not student:
        flash("Student not found.", "danger")
        conn.close()
        return redirect(url_for("admin_dashboard"))

    documents = conn.execute(
        "SELECT * FROM documents WHERE user_id = ?", (student_id,)
    ).fetchall()
    applications = conn.execute(
        "SELECT * FROM applications WHERE user_id = ? ORDER BY id DESC",
        (student_id,)
    ).fetchall()
    conn.close()

    doc_map = {doc["doc_type"]: doc for doc in documents}

    return render_template(
        "admin_view_student.html",
        student=student,
        doc_map=doc_map,
        applications=applications
    )


# ------------------------------------------------------------------
# Admin: Applications list + review
# ------------------------------------------------------------------
@app.route("/admin/applications")
@admin_required
def admin_applications():
    conn = get_db()
    applications = conn.execute("""
        SELECT applications.*, users.full_name, users.email, users.student_id
        FROM applications
        JOIN users ON users.id = applications.user_id
        ORDER BY applications.id DESC
    """).fetchall()
    conn.close()
    return render_template("admin_applications.html", applications=applications)


@app.route("/admin/application/<int:app_id>")
@admin_required
def admin_view_application(app_id):
    conn = get_db()
    application = conn.execute("""
        SELECT applications.*, users.full_name, users.email, users.student_id,
               users.course, users.year_level, users.contact_number, users.address,
               users.id AS student_pk
        FROM applications
        JOIN users ON users.id = applications.user_id
        WHERE applications.id = ?
    """, (app_id,)).fetchone()

    if not application:
        flash("Application not found.", "danger")
        conn.close()
        return redirect(url_for("admin_applications"))

    documents = conn.execute(
        "SELECT * FROM documents WHERE user_id = ?", (application["student_pk"],)
    ).fetchall()
    conn.close()
    doc_map = {doc["doc_type"]: doc for doc in documents}

    return render_template(
        "admin_view_application.html",
        application=application,
        doc_map=doc_map
    )


@app.route("/admin/application/<int:app_id>/update", methods=["POST"])
@admin_required
def admin_update_application(app_id):
    new_status = request.form.get("status")

    if new_status not in ("Approved", "Rejected"):
        flash("Invalid status.", "danger")
        return redirect(url_for("admin_view_application", app_id=app_id))

    conn = get_db()
    conn.execute(
        "UPDATE applications SET status = ? WHERE id = ?",
        (new_status, app_id)
    )
    conn.commit()
    conn.close()

    flash(f"Application has been {new_status.lower()}.", "success")
    return redirect(url_for("admin_view_application", app_id=app_id))


# ------------------------------------------------------------------
# Serve uploaded files (protected — owner or admin only)
# ------------------------------------------------------------------
@app.route("/uploads/<filename>")
def uploaded_file(filename):
    if "user_id" not in session:
        flash("Please log in to view this file.", "warning")
        return redirect(url_for("login"))

    if session.get("role") != "admin":
        if not filename.startswith(f"user{session['user_id']}_"):
            flash("You are not allowed to view this file.", "danger")
            return redirect(url_for("dashboard"))

    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


# ------------------------------------------------------------------
# Run
# ------------------------------------------------------------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
